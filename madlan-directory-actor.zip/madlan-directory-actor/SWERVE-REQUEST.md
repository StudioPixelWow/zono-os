# Track A — ready-to-send message to the `swerve/madlan-analytics` author

Send via Apify actor "Contact / Issues" or the author's listed contact.

---

**Subject: Feature request — add city agent/office *directory* dataType to madlan-analytics**

Hi,

We're building on top of your Madlan actors and they're excellent. We already use **`swerve/madlan-analytics`** in production (with `dataTypes:["deals"]`) and rely on your locality slug format (`{city}-ישראל`, e.g. `רחובות-ישראל`).

We need one capability that isn't currently exposed: the **city agent/office directory** — i.e. the structured data that powers these public Madlan pages:

- `/madad-search/{city}-ישראל`  (city office/agent index)
- `/search-agent`  (agent search)
- `/agentsOffice/{officeEntityId}`  (office profile with its agents)

We do **not** need listing data or HTML scraping — your analytics actor already queries Madlan's **public GraphQL API directly** ("no proxy or anti-bot bypass required"), which is exactly the sanctioned channel we want. Our question: **can you expose the directory through the same actor**, e.g. as `dataTypes:["agents","offices"]` (or `["directory"]`)?

The outputs we need, per city:

**OFFICES** — stable Madlan office entity id · office name · office profile URL · city/locality · phone/address/website (if the source exposes them)
**AGENTS** — stable Madlan agent entity id · full name · agent profile URL · city/locality · phone (if exposed)
**RELATIONSHIPS** — agent entity id → office entity id (the broker→office association **as Madlan states it**)

**Stable source entity ids are the critical part** (e.g. `re_office_…`) — display name alone isn't enough for our use.

Two specific questions:
1. Do the operations behind `/madad-search`, `/search-agent`, and `/agentsOffice/{id}` already exist in your actor's internal GraphQL calls, such that exposing them as new `dataTypes` is low-effort?
2. Are you open to this as a paid/expanded actor tier? We're happy to pay for directory support or a dedicated `madlan-directory` actor if that's cleaner on your side.

We are **not** asking for any anti-bot bypass — only structured access to the same public GraphQL you already use.

Thanks!
