# madlan-directory (Apify actor)

Sanctioned Madlan **city directory** connector for the ZONO `CityDirectoryFetch` seam.
Implements the simple pipeline:

```
city (רחובות)
  → list brokerage offices in the city        (/madad-search/{city}-ישראל, /search-agent)
  → open each office profile                   (/agentsOffice/{officeEntityId})
  → read the agents Madlan associates with it
  → emit offices + agents + source-stated broker→office relationships
```

It observes the **public** Madlan app's own GraphQL traffic (the same public API `swerve/madlan-analytics` uses). **No** anti-bot bypass, **no** cookie theft, **no** fingerprint hacks, **no** private endpoints, **no** fabricated data. Relationships are emitted **only** when Madlan states them.

## Output (one dataset item = the ZONO envelope)

```json
{
  "source": "madlan",
  "locality": "רחובות",
  "status": "success",
  "offices":       [{ "id": "re_office_…", "name": "…", "profileUrl": "…", "city": "רחובות", "phone": null, "address": null, "website": null, "brand": null }],
  "agents":        [{ "id": "re_agent_…", "name": "…", "profileUrl": "…", "city": "רחובות", "phone": null, "role": null, "officeId": "re_office_…" }],
  "relationships": [{ "agentId": "re_agent_…", "officeId": "re_office_…", "agentName": "…", "officeName": "…", "source": "madlan", "observedAt": "…" }],
  "pagination": { "pagesFetched": 0, "entitiesFetched": 0, "sourceExhausted": true, "errors": [], "officeProfilesLoaded": 0, "officeProfilesFailed": 0 }
}
```

The field names match the ZONO `CityDirectoryFetch` normalizer exactly, so ZONO persists it with **zero further code**.

## Modes

- **`debugDiscovery: true`** — load the public directory pages in-browser and record the GraphQL operations they call (operationName, endpoint, variables, response schema). Emits a contract report to the dataset + the key-value store `discovered-contract`. Run this **first** to capture the real contract.
- **Browser-capture production** (default) — visits city + each office profile and normalizes the page's own GraphQL responses.
- **API-first production** — after discovery, paste the captured contract into `input.graphql` (`endpoint`, `query`, `variables`, pagination paths) and optionally `input.mapping` (explicit JSON paths). The actor then calls the GraphQL directly (no browser).

## Deploy (copy/paste)

1. Open **Apify Console → Actors → Create new → From source**.
2. Upload/paste this folder (`.actor/`, `src/`, `tests/`, `Dockerfile`, `package.json`, `tsconfig.json`).
3. Set the actor's **Docker file** to the provided `Dockerfile` (Playwright base).
4. **Build** the actor.
5. **Run — discovery first:**
   ```json
   { "city": "רחובות", "includeOffices": true, "includeAgents": true, "includeRelationships": true, "debugDiscovery": true }
   ```
6. Inspect the dataset + KV store `discovered-contract`. Confirm real office/agent GraphQL operations were captured.
7. **Run — production** (browser-capture works immediately; or paste the captured contract into `graphql`/`mapping` for API-first):
   ```json
   { "city": "רחובות", "includeOffices": true, "includeAgents": true, "includeRelationships": true }
   ```
8. Confirm the dataset item has real `offices` / `agents` / `relationships`.
9. Copy the actor id (`<owner>/madlan-directory`).

## Wire into ZONO (Vercel)

Set env on the ZONO project and redeploy:

```
APIFY_MADLAN_DIRECTORY_ACTOR_ID = <owner>/madlan-directory
# confirm APIFY_TOKEN already exists (it does — used by the listing/analytics actors)
```

Then trigger ingestion (any one):
- the daily cron `madlan-directory-refresh` (03:30 UTC),
- the **"רענן מדריך"** button on `מדריך המשרדים`,
- `curl -H "authorization: Bearer $CRON_SECRET" https://<app>/api/cron/madlan-directory-refresh`.

ZONO's already-built seam consumes the envelope: upserts `brokerage_offices` / `brokerage_agents` / `brokerage_broker_identity` idempotently with `metadata.source='madlan_directory'`, `resolution_method='madlan_directory'`, `providers=['madlan']`, freshness stamps — **no migration**.

## Tests

`node --test --loader ts-node/esm tests/normalize.test.ts` — 11 pure-logic tests (office/agent/relationship/no-office/duplicate/pagination/changed-relationship/partial/failure/name-fallback).
