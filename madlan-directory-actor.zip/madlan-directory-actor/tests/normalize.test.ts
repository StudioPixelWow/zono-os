// Actor-level tests for the pure normalizer (no network, no DB).
// Run: node --test --loader ts-node/esm tests/normalize.test.ts
import { test } from "node:test";
import assert from "node:assert/strict";
import { normalizeToEnvelope, dedupeOffices, dedupeAgents, dedupeRelationships } from "../src/normalize.js";

const AT = "2026-01-01T00:00:00.000Z";

test("office record → normalized office with stable id", () => {
  const resp = { data: { offices: [{ id: "re_office_ABC", officeName: "קבוצת אלרם נדל\"ן", url: "/agentsOffice/re_office_ABC", city: "רחובות", phone: "08-1234567" }] } };
  const env = normalizeToEnvelope([resp], { city: "רחובות", mapping: { officesPath: "data.offices" }, includeAgents: false, includeRelationships: false, observedAt: AT });
  assert.equal(env.offices.length, 1);
  assert.equal(env.offices[0].id, "re_office_ABC");
  assert.equal(env.offices[0].identityFallback, null);
  assert.equal(env.offices[0].profileUrl, "/agentsOffice/re_office_ABC");
});

test("agent record with source-stated office → relationship derived (not inferred)", () => {
  const resp = { data: { agents: [{ agentId: "re_agent_1", agentName: "רחלי פרץ", officeId: "re_office_ABC", city: "רחובות" }] } };
  const env = normalizeToEnvelope([resp], { city: "רחובות", mapping: { agentsPath: "data.agents" }, includeOffices: false, observedAt: AT });
  assert.equal(env.agents.length, 1);
  assert.equal(env.agents[0].officeId, "re_office_ABC");
  assert.equal(env.relationships.length, 1);
  assert.equal(env.relationships[0].agentId, "re_agent_1");
  assert.equal(env.relationships[0].officeId, "re_office_ABC");
});

test("agent without office → NO relationship (never inferred)", () => {
  const resp = { data: { agents: [{ agentId: "re_agent_2", agentName: "מתווך ללא משרד", city: "רחובות" }] } };
  const env = normalizeToEnvelope([resp], { city: "רחובות", mapping: { agentsPath: "data.agents" }, includeOffices: false, observedAt: AT });
  assert.equal(env.agents.length, 1);
  assert.equal(env.agents[0].officeId, null);
  assert.equal(env.relationships.length, 0);
});

test("duplicate office by stable id → merged once", () => {
  const r = dedupeOffices([
    { id: "re_office_X", name: "A", profileUrl: null, city: "רחובות", phone: null, address: null, website: null, brand: null },
    { id: "re_office_X", name: "A", profileUrl: null, city: "רחובות", phone: null, address: null, website: null, brand: null },
  ]);
  assert.equal(r.list.length, 1);
  assert.equal(r.merged, 1);
});

test("duplicate agent by stable id → merged once", () => {
  const r = dedupeAgents([
    { id: "re_agent_9", name: "X", profileUrl: null, city: null, phone: null, role: null, officeId: null },
    { id: "re_agent_9", name: "X", profileUrl: null, city: null, phone: null, role: null, officeId: null },
  ]);
  assert.equal(r.list.length, 1);
  assert.equal(r.merged, 1);
});

test("pagination — multiple responses aggregate + dedupe", () => {
  const p1 = { data: { offices: [{ id: "o1", officeName: "One", url: "/agentsOffice/o1" }] } };
  const p2 = { data: { offices: [{ id: "o1", officeName: "One", url: "/agentsOffice/o1" }, { id: "o2", officeName: "Two", url: "/agentsOffice/o2" }] } };
  const env = normalizeToEnvelope([p1, p2], { city: "רחובות", mapping: { officesPath: "data.offices" }, includeAgents: false, includeRelationships: false, observedAt: AT });
  assert.equal(env.offices.length, 2);
});

test("changed office relationship — latest officeId wins after re-run", () => {
  const before = normalizeToEnvelope([{ data: { agents: [{ agentId: "a1", agentName: "N", officeId: "o_old" }] } }], { city: "רחובות", mapping: { agentsPath: "data.agents" }, includeOffices: false, observedAt: AT });
  const after = normalizeToEnvelope([{ data: { agents: [{ agentId: "a1", agentName: "N", officeId: "o_new" }] } }], { city: "רחובות", mapping: { agentsPath: "data.agents" }, includeOffices: false, observedAt: AT });
  assert.equal(before.relationships[0].officeId, "o_old");
  assert.equal(after.relationships[0].officeId, "o_new");
});

test("partial response — missing arrays yield empty, no throw", () => {
  const env = normalizeToEnvelope([{ data: {} }, null, "garbage"], { city: "רחובות", observedAt: AT });
  assert.equal(env.offices.length, 0);
  assert.equal(env.agents.length, 0);
  assert.equal(env.relationships.length, 0);
});

test("provider failure — empty responses yield empty envelope", () => {
  const env = normalizeToEnvelope([], { city: "רחובות", observedAt: AT });
  assert.equal(env.offices.length + env.agents.length + env.relationships.length, 0);
  assert.equal(env.locality, "רחובות");
});

test("name-only identity is flagged as fallback", () => {
  const resp = { agents: [{ agentName: "שם בלבד", type: "agent" }] };
  const env = normalizeToEnvelope([resp], { city: "רחובות", includeOffices: false, includeRelationships: false, observedAt: AT });
  assert.equal(env.agents.length, 1);
  assert.equal(env.agents[0].id, null);
  assert.equal(env.agents[0].identityFallback, "name");
});

test("relationship dedupe by agent+office+source", () => {
  const r = dedupeRelationships([
    { agentId: "a", officeId: "o", agentName: "", officeName: "", source: "madlan", observedAt: AT },
    { agentId: "a", officeId: "o", agentName: "", officeName: "", source: "madlan", observedAt: AT },
  ]);
  assert.equal(r.list.length, 1);
});
