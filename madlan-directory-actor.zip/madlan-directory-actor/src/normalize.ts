// ============================================================================
// normalize.ts — convert captured Madlan directory JSON → CityDirectoryEnvelope.
// Pure & dependency-free (unit-testable). Two modes:
//   1. mapping-driven (precise) — explicit JSON paths captured from discovery.
//   2. heuristic (best-effort)  — when no mapping is supplied yet.
// Identity rule: prefer stable source id → else profileUrl → else name (flagged
// as fallback). Relationships ONLY when the source states them (agent.officeId
// or an explicit relationship node); NEVER inferred here.
// ============================================================================
import type {
  DirectoryOfficeOut, DirectoryAgentOut, DirectoryRelationshipOut,
  CityDirectoryEnvelope, FieldMapping,
} from "./types.js";

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => !!v && typeof v === "object" && !Array.isArray(v);
const str = (v: unknown): string | null => (v == null || v === "" ? null : String(v).trim());

/** Dot-path getter; a `[]` segment or an array in the path flattens one level. */
export function getPath(root: unknown, path?: string): unknown {
  if (!path) return undefined;
  let cur: unknown = root;
  for (const seg of path.split(".")) {
    if (seg === "" || seg === "[]") continue;
    if (Array.isArray(cur)) cur = cur.map((x) => (isObj(x) ? x[seg] : undefined));
    else if (isObj(cur)) cur = cur[seg];
    else return undefined;
  }
  return cur;
}

/** Collect candidate nodes: explicit path → array; else deep-scan for arrays of
 *  objects that pass `looks`. */
function collectNodes(root: unknown, path: string | undefined, looks: (o: Obj) => boolean): Obj[] {
  if (path) {
    const at = getPath(root, path);
    const arr = Array.isArray(at) ? at : at != null ? [at] : [];
    return arr.filter(isObj);
  }
  const out: Obj[] = [];
  const stack: unknown[] = [root];
  let guard = 0;
  while (stack.length && guard < 20000) {
    guard++;
    const cur = stack.pop();
    if (Array.isArray(cur)) {
      if (cur.length && isObj(cur[0]) && looks(cur[0] as Obj)) { for (const x of cur) if (isObj(x)) out.push(x); continue; }
      for (const x of cur) stack.push(x);
    } else if (isObj(cur)) {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return out;
}

const ID_KEYS = ["id", "docId", "entityId", "madlanId", "officeId", "agentId", "slug", "_id"];
const NAME_KEYS = ["name", "officeName", "office_name", "agentName", "agent_name", "fullName", "full_name", "title", "displayName"];
const URL_KEYS = ["url", "profileUrl", "officeUrl", "agentUrl", "link", "href", "pageUrl"];

const firstKey = (o: Obj, keys: string[]): string | null => {
  for (const k of keys) { const v = str(o[k]); if (v) return v; }
  return null;
};

function looksLikeOffice(o: Obj): boolean {
  const keys = Object.keys(o).map((k) => k.toLowerCase());
  const hasName = keys.some((k) => /office|agency|company|business/.test(k) && /name|title/.test(k)) || keys.includes("officename");
  const officeId = keys.some((k) => /office/.test(k) && /id|slug/.test(k)) || (o.type && /office|agency|משרד/.test(String(o.type)));
  return (hasName || !!officeId) && !!firstKey(o, NAME_KEYS);
}
function looksLikeAgent(o: Obj): boolean {
  const keys = Object.keys(o).map((k) => k.toLowerCase());
  const agentish = keys.some((k) => /agent|broker|realtor|מתווך/.test(k)) || (o.type && /agent|broker|מתווך/.test(String(o.type)));
  return !!agentish && !!firstKey(o, NAME_KEYS);
}

function identity(o: Obj, idKeys: string[]): { id: string | null; fallback: "name" | "profileUrl" | null } {
  const id = firstKey(o, idKeys) ?? firstKey(o, ID_KEYS);
  if (id) return { id, fallback: null };
  const url = firstKey(o, URL_KEYS);
  if (url) return { id: url, fallback: "profileUrl" };
  return { id: null, fallback: "name" };
}

function mapOffice(o: Obj, m?: FieldMapping["office"]): DirectoryOfficeOut {
  const g = (field: string, keys: string[]) => (m && m[field as keyof typeof m] ? str(getPath(o, m[field as keyof typeof m] as string)) : firstKey(o, keys));
  const name = g("name", NAME_KEYS) ?? "";
  const ident = m?.id ? { id: str(getPath(o, m.id)), fallback: null as null } : identity(o, ["officeId", "office_id"]);
  return {
    id: ident.id, name, profileUrl: g("profileUrl", URL_KEYS),
    city: g("city", ["city", "cityName", "locality", "settlement"]),
    phone: g("phone", ["phone", "primaryPhone", "phoneNumber", "tel"]),
    address: g("address", ["address", "fullAddress", "streetAddress"]),
    website: g("website", ["website", "websiteUrl", "domain", "site"]),
    brand: g("brand", ["brand", "brandNetwork", "network", "franchise"]),
    identityFallback: (m?.id ? (ident.id ? null : "name") : ident.fallback),
    sourceMetadata: scalarMeta(o),
  };
}

function mapAgent(o: Obj, m?: FieldMapping["agent"]): DirectoryAgentOut {
  const g = (field: string, keys: string[]) => (m && m[field as keyof typeof m] ? str(getPath(o, m[field as keyof typeof m] as string)) : firstKey(o, keys));
  const name = g("name", NAME_KEYS) ?? "";
  const ident = m?.id ? { id: str(getPath(o, m.id)), fallback: null as null } : identity(o, ["agentId", "agent_id"]);
  const officeId = m?.officeId ? str(getPath(o, m.officeId)) : firstKey(o, ["officeId", "office_id", "officeEntityId", "parentOfficeId", "officeSourceId"]);
  return {
    id: ident.id, name, profileUrl: g("profileUrl", URL_KEYS),
    city: g("city", ["city", "cityName", "locality", "settlement"]),
    phone: g("phone", ["phone", "primaryPhone", "phoneNumber", "tel", "mobile"]),
    role: g("role", ["role", "roleTitle", "title", "position"]),
    officeId: officeId ?? null,
    identityFallback: (m?.id ? (ident.id ? null : "name") : ident.fallback),
    sourceMetadata: scalarMeta(o),
  };
}

function scalarMeta(o: Obj): Record<string, unknown> | null {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(o)) {
    if (v == null) continue;
    if (typeof v === "string" && v.length <= 200) out[k] = v;
    else if (typeof v === "number" || typeof v === "boolean") out[k] = v;
  }
  return Object.keys(out).length ? out : null;
}

export function dedupeOffices(list: DirectoryOfficeOut[]): { list: DirectoryOfficeOut[]; merged: number } {
  const seen = new Map<string, DirectoryOfficeOut>();
  let merged = 0;
  for (const o of list) {
    const key = (o.id ?? `name:${o.name}|${o.city ?? ""}`).toLowerCase();
    if (seen.has(key)) { merged++; continue; }
    seen.set(key, o);
  }
  return { list: [...seen.values()], merged };
}
export function dedupeAgents(list: DirectoryAgentOut[]): { list: DirectoryAgentOut[]; merged: number } {
  const seen = new Map<string, DirectoryAgentOut>();
  let merged = 0;
  for (const a of list) {
    const key = (a.id ?? `name:${a.name}|${a.city ?? ""}`).toLowerCase();
    if (seen.has(key)) { merged++; continue; }
    seen.set(key, a);
  }
  return { list: [...seen.values()], merged };
}
export function dedupeRelationships(list: DirectoryRelationshipOut[]): { list: DirectoryRelationshipOut[]; merged: number } {
  const seen = new Set<string>();
  const out: DirectoryRelationshipOut[] = [];
  let merged = 0;
  for (const r of list) {
    const key = `${r.agentId ?? r.agentName}|${r.officeId ?? r.officeName}|${r.source}`.toLowerCase();
    if (seen.has(key)) { merged++; continue; }
    seen.add(key); out.push(r);
  }
  return { list: out, merged };
}

export interface NormalizeOpts {
  city: string;
  mapping?: FieldMapping;
  includeOffices?: boolean;
  includeAgents?: boolean;
  includeRelationships?: boolean;
  observedAt: string;
}

/** Normalize an array of raw GraphQL responses into a deduped envelope. */
export function normalizeToEnvelope(responses: unknown[], opts: NormalizeOpts): Omit<CityDirectoryEnvelope, "status" | "reason" | "pagination"> & { entitiesFetched: number } {
  const m = opts.mapping;
  const rawOffices: DirectoryOfficeOut[] = [];
  const rawAgents: DirectoryAgentOut[] = [];
  const rawRels: DirectoryRelationshipOut[] = [];

  for (const resp of responses) {
    if (opts.includeOffices !== false) {
      for (const node of collectNodes(resp, m?.officesPath, looksLikeOffice)) {
        const o = mapOffice(node, m?.office);
        if (o.name) rawOffices.push(o);
      }
    }
    if (opts.includeAgents !== false) {
      for (const node of collectNodes(resp, m?.agentsPath, looksLikeAgent)) {
        const a = mapAgent(node, m?.agent);
        if (a.name) rawAgents.push(a);
      }
    }
    if (opts.includeRelationships !== false && m?.relationshipsPath) {
      for (const node of collectNodes(resp, m.relationshipsPath, () => true)) {
        const rm = m.relationship;
        const agentId = rm?.agentId ? str(getPath(node, rm.agentId)) : firstKey(node, ["agentId", "agent_id"]);
        const officeId = rm?.officeId ? str(getPath(node, rm.officeId)) : firstKey(node, ["officeId", "office_id"]);
        if (!officeId) continue; // source must state the office
        rawRels.push({
          agentId, officeId,
          agentName: (rm?.agentName ? str(getPath(node, rm.agentName)) : firstKey(node, ["agentName", "agent_name"])) ?? "",
          officeName: (rm?.officeName ? str(getPath(node, rm.officeName)) : firstKey(node, ["officeName", "office_name"])) ?? "",
          source: "madlan", observedAt: opts.observedAt,
        });
      }
    }
  }

  // Derive relationships from agents that carry a source-stated officeId (never
  // inferred — the officeId must have come from the source record itself).
  if (opts.includeRelationships !== false) {
    for (const a of rawAgents) {
      if (a.officeId) rawRels.push({ agentId: a.id, officeId: a.officeId, agentName: a.name, officeName: "", source: "madlan", observedAt: opts.observedAt });
    }
  }

  const offices = dedupeOffices(rawOffices);
  const agents = dedupeAgents(rawAgents);
  const rels = dedupeRelationships(rawRels);

  return {
    source: "madlan", locality: opts.city, observedAt: opts.observedAt,
    offices: offices.list, agents: agents.list, relationships: rels.list,
    entitiesFetched: offices.list.length + agents.list.length,
  };
}

export const _internals = { getPath, collectNodes, looksLikeOffice, looksLikeAgent, mapOffice, mapAgent };
