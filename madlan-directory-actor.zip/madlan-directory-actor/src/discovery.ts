// ============================================================================
// discovery.ts — SANCTIONED capture for the SIMPLE pipeline:
//   city directory page → office list → per-office profile page → office agents.
// Loads PUBLIC Madlan pages inside Apify with a headless browser and records the
// GraphQL responses the page ITSELF legitimately makes. No anti-bot bypass, no
// cookie theft, no fingerprint hacks, no private endpoints — it observes the
// public app's own traffic. Returns raw JSON responses for normalization.
// ============================================================================
import { chromium, type Browser, type BrowserContext, type Response } from "playwright";
import type { CapturedExchange } from "./types.js";

export const DIRECTORY_BASE = "https://www.madlan.co.il";

/** City → Madlan locality slug, matching /madad-search/{city}-ישראל. */
export function citySlug(city: string): string {
  return `${city.trim().replace(/["'׳״]/g, "").replace(/\s+/g, "-")}-ישראל`;
}

export interface CaptureResult {
  exchanges: CapturedExchange[];
  responses: unknown[];
  pagesFetched: number;
  errors: string[];
}

const looksLikeGraphql = (url: string, ct: string | undefined): boolean =>
  /graphql|\/api|\/gql|query/i.test(url) && !!ct && /json/i.test(ct);

const directoryish = (json: unknown): boolean =>
  /office|agent|broker|madad|מתווך|משרד|agentsoffice/.test(JSON.stringify(json ?? "").toLowerCase());

function parsePostData(pd: string | null): { operationName: string | null; variables: unknown } {
  if (!pd) return { operationName: null, variables: null };
  try {
    const j = JSON.parse(pd) as Record<string, unknown> | Array<Record<string, unknown>>;
    const first = Array.isArray(j) ? j[0] : j;
    return { operationName: (first?.operationName as string) ?? null, variables: first?.variables ?? null };
  } catch { return { operationName: null, variables: null }; }
}

function attachCapture(ctx: BrowserContext, sink: { exchanges: CapturedExchange[]; responses: unknown[] }): void {
  ctx.on("response", (res: Response) => {
    void (async () => {
      try {
        const url = res.url();
        const ct = res.headers()["content-type"];
        if (!looksLikeGraphql(url, ct)) return;
        let body: unknown = null;
        try { body = await res.json(); } catch { return; }
        if (!directoryish(body)) return;
        const { operationName, variables } = parsePostData(res.request().postData());
        sink.responses.push(body);
        sink.exchanges.push({
          operationName, url, method: res.request().method(), variables,
          responseKeys: body && typeof body === "object" ? Object.keys(body as Record<string, unknown>) : [],
          responseSample: truncate(body), looksLikeDirectory: true,
        });
      } catch { /* ignore individual response errors */ }
    })();
  });
}

/** Visit a list of public URLs, scroll to trigger the app's own pagination, and
 *  capture directory GraphQL responses. Bounded, conservative, never throws. */
export async function captureUrls(urls: string[], opts: { maxPages: number; requestTimeoutSecs: number; scroll?: boolean }): Promise<CaptureResult> {
  const sink = { exchanges: [] as CapturedExchange[], responses: [] as unknown[] };
  const errors: string[] = [];
  let pagesFetched = 0;
  let browser: Browser | null = null;
  try {
    browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
    const context = await browser.newContext({ locale: "he-IL", viewport: { width: 1366, height: 900 } });
    attachCapture(context, sink);
    const page = await context.newPage();
    for (const url of urls) {
      if (pagesFetched >= opts.maxPages) break;
      try {
        await page.goto(url, { waitUntil: "networkidle", timeout: opts.requestTimeoutSecs * 1000 });
        pagesFetched++;
        if (opts.scroll !== false) {
          for (let i = 0; i < 12; i++) { await page.mouse.wheel(0, 2400); await page.waitForTimeout(700); }
        }
      } catch (e) { errors.push(`goto ${url}: ${e instanceof Error ? e.message : "failed"}`); }
    }
    await context.close();
  } catch (e) {
    errors.push(e instanceof Error ? e.message : "browser capture failed");
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
  return { exchanges: sink.exchanges, responses: sink.responses, pagesFetched, errors };
}

/** STEP 1 — city directory: list the offices in the city. */
export function cityDirectoryUrls(city: string): string[] {
  return [`${DIRECTORY_BASE}/madad-search/${citySlug(city)}`, `${DIRECTORY_BASE}/search-agent`];
}

/** STEP 2 — office profile URL from a stable office id (or a captured URL). */
export function officeProfileUrl(idOrUrl: string): string {
  if (/^https?:\/\//i.test(idOrUrl)) return idOrUrl;
  return `${DIRECTORY_BASE}/agentsOffice/${idOrUrl}`;
}

function truncate(v: unknown, max = 4000): unknown {
  const s = JSON.stringify(v);
  if (s.length <= max) return v;
  try { return JSON.parse(s.slice(0, max)); } catch { return { _truncated: true, preview: s.slice(0, max) }; }
}
