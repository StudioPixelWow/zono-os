// ============================================================================
// main.ts — Madlan City Directory actor (SIMPLE pipeline):
//   רחובות → list offices → open each office profile → read its agents →
//   emit offices + agents + source-stated broker→office relationships.
// Output = ONE dataset item = the CityDirectoryEnvelope the ZONO
// CityDirectoryFetch seam consumes. No fabricated data; no anti-bot bypass;
// relationships ONLY when Madlan states them.
// ============================================================================
import { Actor } from "apify";
import type { ActorInput, CityDirectoryEnvelope, DirectoryAgentOut, DirectoryOfficeOut } from "./types.js";
import { captureUrls, cityDirectoryUrls, officeProfileUrl } from "./discovery.js";
import { fetchViaGraphql } from "./graphql.js";
import { normalizeToEnvelope, dedupeOffices, dedupeAgents, dedupeRelationships } from "./normalize.js";

await Actor.init();

const input = (await Actor.getInput<ActorInput>()) ?? ({} as ActorInput);
const city = (input.city ?? "").trim();
const observedAt = new Date().toISOString();
const maxPages = input.maxPages ?? 50;
const requestTimeoutSecs = input.requestTimeoutSecs ?? 30;
const MAX_OFFICE_PROFILES = Math.min(maxPages, 120); // rate safety

function envelope(p: Partial<CityDirectoryEnvelope>): CityDirectoryEnvelope {
  return {
    source: "madlan", locality: city, status: "success", reason: null,
    offices: [], agents: [], relationships: [],
    pagination: { pagesFetched: 0, entitiesFetched: 0, sourceExhausted: false, errors: [] },
    observedAt, ...p,
  };
}

if (!city) { await Actor.pushData(envelope({ status: "error", reason: "city is required" })); await Actor.exit(); }

try {
  // ── Discovery mode: capture the contract, emit a report, don't normalize. ──
  if (input.debugDiscovery) {
    const cap = await captureUrls(cityDirectoryUrls(city), { maxPages, requestTimeoutSecs });
    await Actor.setValue("discovered-contract", { city, capturedAt: observedAt, exchanges: cap.exchanges });
    for (const ex of cap.exchanges) await Actor.pushData({ _type: "discovery_exchange", ...ex });
    await Actor.pushData(envelope({
      status: "discovery",
      reason: `discovery: ${cap.exchanges.length} directory GraphQL exchange(s) captured — inspect KV store "discovered-contract".`,
      pagination: { pagesFetched: cap.pagesFetched, entitiesFetched: 0, sourceExhausted: false, errors: cap.errors },
    }));
    await Actor.exit();
  }

  const errors: string[] = [];
  let pagesFetched = 0;
  let officeProfilesLoaded = 0;
  let officeProfilesFailed = 0;

  // ── STEP 1 — city directory → offices ─────────────────────────────────────
  let step1Responses: unknown[] = [];
  if (input.graphql?.endpoint && input.graphql?.query) {
    const r = await fetchViaGraphql(input.graphql, city, { maxPages, requestTimeoutSecs });
    step1Responses = r.responses; pagesFetched += r.pagesFetched; errors.push(...r.errors);
  } else {
    const cap = await captureUrls(cityDirectoryUrls(city), { maxPages, requestTimeoutSecs });
    step1Responses = cap.responses; pagesFetched += cap.pagesFetched; errors.push(...cap.errors);
  }
  const cityNorm = normalizeToEnvelope(step1Responses, { city, mapping: input.mapping, includeAgents: false, includeRelationships: false, observedAt });
  const offices: DirectoryOfficeOut[] = cityNorm.offices;

  // ── STEP 2 — each office profile → its agents (source-stated relationship) ──
  const agents: DirectoryAgentOut[] = [];
  if (input.includeAgents !== false) {
    const targets = offices
      .map((o) => ({ office: o, url: o.profileUrl ?? (o.id ? officeProfileUrl(o.id) : null) }))
      .filter((t): t is { office: DirectoryOfficeOut; url: string } => !!t.url)
      .slice(0, MAX_OFFICE_PROFILES);

    for (const { office, url } of targets) {
      try {
        const cap = await captureUrls([url], { maxPages: 1, requestTimeoutSecs, scroll: true });
        pagesFetched += cap.pagesFetched;
        if (cap.responses.length === 0) { officeProfilesFailed++; if (cap.errors[0]) errors.push(cap.errors[0]); continue; }
        officeProfilesLoaded++;
        const prof = normalizeToEnvelope(cap.responses, { city, mapping: input.mapping, includeOffices: false, includeRelationships: false, observedAt });
        // Attach the office association from the SOURCE context (we are on the
        // office's own profile page → agents here belong to THIS office).
        for (const a of prof.agents) agents.push({ ...a, officeId: a.officeId ?? office.id ?? office.profileUrl });
      } catch (e) { officeProfilesFailed++; errors.push(`office ${office.id ?? office.name}: ${e instanceof Error ? e.message : "profile failed"}`); }
    }
  }

  // ── Merge → relationships derive ONLY from source-stated office linkage ────
  const finalEnv = buildEnvelope(city, offices, agents, observedAt);
  const status: CityDirectoryEnvelope["status"] =
    step1Responses.length === 0 ? "partial" : errors.length ? "partial" : "success";

  await Actor.pushData({
    ...finalEnv,
    status,
    reason: step1Responses.length === 0 ? "no city directory responses captured — run debugDiscovery to inspect the contract" : null,
    pagination: {
      pagesFetched, entitiesFetched: finalEnv.offices.length + finalEnv.agents.length,
      sourceExhausted: true, errors,
      // extra operational metrics (safe, non-secret)
      officeProfilesLoaded, officeProfilesFailed,
    } as CityDirectoryEnvelope["pagination"] & { officeProfilesLoaded: number; officeProfilesFailed: number },
  });
} catch (e) {
  await Actor.pushData(envelope({ status: "error", reason: e instanceof Error ? e.message : "actor failed" }));
}

await Actor.exit();

// Build a deduped envelope from collected offices+agents; relationships come
// ONLY from agents carrying a source-stated officeId.
function buildEnvelope(cityName: string, officesIn: DirectoryOfficeOut[], agentsIn: DirectoryAgentOut[], ts: string): CityDirectoryEnvelope {
  const offices = dedupeOffices(officesIn).list;
  const agents = dedupeAgents(agentsIn).list;
  const byOfficeId = new Map(offices.filter((o) => o.id).map((o) => [o.id as string, o.name] as const));
  const relationships = dedupeRelationships(
    agents
      .filter((a) => a.officeId)
      .map((a) => ({ agentId: a.id, officeId: a.officeId, agentName: a.name, officeName: byOfficeId.get(a.officeId as string) ?? "", source: "madlan", observedAt: ts })),
  ).list;
  return {
    source: "madlan", locality: cityName, status: "success", reason: null,
    offices, agents, relationships,
    pagination: { pagesFetched: 0, entitiesFetched: offices.length + agents.length, sourceExhausted: true, errors: [] },
    observedAt: ts,
  };
}
