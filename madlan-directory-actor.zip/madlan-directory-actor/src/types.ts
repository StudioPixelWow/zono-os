// ============================================================================
// Types — the actor's output envelope MATCHES the ZONO CityDirectoryFetch seam.
// The ZONO seeder's partition() accepts a single dataset item shaped like this
// (envelope with offices/agents/relationships arrays). Field names are chosen to
// match the ZONO normalizer's `pick()` keys exactly.
// ============================================================================

export interface DirectoryOfficeOut {
  /** Stable Madlan office entity id (e.g. re_office_…). PRIMARY identity. */
  id: string | null;
  name: string;
  profileUrl: string | null;
  city: string | null;
  phone: string | null;
  address: string | null;
  website: string | null;
  brand: string | null;
  /** Marks name-only identity when no stable id was exposed by the source. */
  identityFallback?: "name" | "profileUrl" | null;
  sourceMetadata?: Record<string, unknown> | null;
}

export interface DirectoryAgentOut {
  /** Stable Madlan agent entity id. PRIMARY identity. */
  id: string | null;
  name: string;
  profileUrl: string | null;
  city: string | null;
  phone: string | null;
  role: string | null;
  /** Office the SOURCE associates this agent with (stable office id). Null when
   *  the source states none — NEVER inferred inside the actor. */
  officeId: string | null;
  identityFallback?: "name" | "profileUrl" | null;
  sourceMetadata?: Record<string, unknown> | null;
}

export interface DirectoryRelationshipOut {
  agentId: string | null;
  officeId: string | null;
  agentName: string;
  officeName: string;
  source: string;
  observedAt: string;
}

export interface DirectoryPaginationOut {
  pagesFetched: number;
  entitiesFetched: number;
  sourceExhausted: boolean;
  errors: string[];
}

export type DirectoryStatus = "success" | "partial" | "discovery" | "error";

export interface CityDirectoryEnvelope {
  source: "madlan";
  locality: string;
  status: DirectoryStatus;
  reason: string | null;
  offices: DirectoryOfficeOut[];
  agents: DirectoryAgentOut[];
  relationships: DirectoryRelationshipOut[];
  pagination: DirectoryPaginationOut;
  observedAt: string;
}

// ── Input ────────────────────────────────────────────────────────────────────

export interface GraphqlContract {
  endpoint: string;
  method?: "POST" | "GET";
  headers?: Record<string, string>;
  /** Operation used for the city office/agent directory. */
  operationName?: string;
  query?: string;
  /** Variables template; {{city}} / {{page}} / {{cursor}} placeholders allowed. */
  variables?: Record<string, unknown>;
  /** Where the next-page cursor/flag lives in the response (dot path). */
  nextCursorPath?: string;
  hasNextPagePath?: string;
}

export interface FieldMapping {
  /** Dot path to the array of office nodes in the response. */
  officesPath?: string;
  agentsPath?: string;
  relationshipsPath?: string;
  office?: Partial<Record<keyof DirectoryOfficeOut, string>>;
  agent?: Partial<Record<keyof DirectoryAgentOut, string>>;
  relationship?: Partial<Record<keyof DirectoryRelationshipOut, string>>;
}

export interface ActorInput {
  city: string;
  includeOffices?: boolean;
  includeAgents?: boolean;
  includeRelationships?: boolean;
  maxPages?: number;
  debugDiscovery?: boolean;
  graphql?: GraphqlContract;
  mapping?: FieldMapping;
  maxConcurrency?: number;
  requestTimeoutSecs?: number;
}

/** A captured GraphQL exchange recorded by discovery mode (for inspection). */
export interface CapturedExchange {
  operationName: string | null;
  url: string;
  method: string;
  variables: unknown;
  responseKeys: string[];
  responseSample: unknown;
  looksLikeDirectory: boolean;
}
