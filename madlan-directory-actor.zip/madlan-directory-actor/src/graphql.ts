// ============================================================================
// graphql.ts — API-first production path. Once discovery captures the real
// operation, paste the contract into input.graphql and the actor calls the
// public Madlan GraphQL endpoint DIRECTLY (no browser). Bounded, backoff,
// pagination-aware. It NEVER invents an operation — it only executes the
// contract supplied from discovery.
// ============================================================================
import type { GraphqlContract } from "./types.js";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function getPath(root: unknown, path?: string): unknown {
  if (!path) return undefined;
  let cur: unknown = root;
  for (const seg of path.split(".")) {
    if (!seg) continue;
    if (cur && typeof cur === "object") cur = (cur as Record<string, unknown>)[seg];
    else return undefined;
  }
  return cur;
}

function fillVars(vars: Record<string, unknown> | undefined, city: string, page: number, cursor: string | null): Record<string, unknown> {
  const raw = JSON.stringify(vars ?? {});
  const filled = raw
    .replace(/"\{\{city\}\}"/g, JSON.stringify(city))
    .replace(/\{\{city\}\}/g, city)
    .replace(/"\{\{page\}\}"/g, String(page))
    .replace(/\{\{page\}\}/g, String(page))
    .replace(/"\{\{cursor\}\}"/g, JSON.stringify(cursor))
    .replace(/\{\{cursor\}\}/g, cursor ?? "");
  try { return JSON.parse(filled) as Record<string, unknown>; } catch { return vars ?? {}; }
}

export interface GraphqlFetchResult {
  responses: unknown[];
  pagesFetched: number;
  sourceExhausted: boolean;
  errors: string[];
}

/** Execute the captured GraphQL contract with bounded pagination + backoff. */
export async function fetchViaGraphql(
  contract: GraphqlContract, city: string,
  opts: { maxPages: number; requestTimeoutSecs: number },
): Promise<GraphqlFetchResult> {
  const responses: unknown[] = [];
  const errors: string[] = [];
  let pagesFetched = 0;
  let sourceExhausted = false;
  let cursor: string | null = null;

  for (let page = 1; page <= opts.maxPages; page++) {
    const variables = fillVars(contract.variables, city, page, cursor);
    const body = JSON.stringify({ operationName: contract.operationName ?? null, query: contract.query, variables });
    let ok = false;
    for (let attempt = 0; attempt < 3 && !ok; attempt++) {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), opts.requestTimeoutSecs * 1000);
      try {
        const res = await fetch(contract.endpoint, {
          method: contract.method ?? "POST",
          headers: { "content-type": "application/json", accept: "application/json", ...(contract.headers ?? {}) },
          body, signal: ctrl.signal,
        });
        if (!res.ok) throw new Error(`http ${res.status}`);
        const json = await res.json();
        responses.push(json);
        pagesFetched++;
        ok = true;
        // Pagination: advance by cursor/hasNextPage if the contract defines it.
        const hasNext = contract.hasNextPagePath ? Boolean(getPath(json, contract.hasNextPagePath)) : false;
        const nextCursor = contract.nextCursorPath ? getPath(json, contract.nextCursorPath) : null;
        if (!hasNext || nextCursor == null) { sourceExhausted = true; }
        cursor = nextCursor == null ? null : String(nextCursor);
      } catch (e) {
        clearTimeout(t);
        if (attempt === 2) errors.push(`page ${page}: ${e instanceof Error ? e.message : "graphql failed"}`);
        else await sleep(500 * Math.pow(2, attempt)); // exponential backoff
        continue;
      }
      clearTimeout(t);
    }
    if (!ok || sourceExhausted) break;
    await sleep(400); // conservative inter-page delay
  }
  return { responses, pagesFetched, sourceExhausted, errors };
}
